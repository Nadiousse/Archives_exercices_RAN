a = float(input("Veuillez entrer un nombre : "))
b = float(input("Veuillez entrer un nombre : "))

print(a," + ", b, " = ", a+b)
print(a," - ", b, " = ", a-b)
print(a," x ", b, " = ", a*b)
print(a," / ", b, " = ", a/b)