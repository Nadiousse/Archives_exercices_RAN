a = float(input("Veuillez entrer un nombre à multiplier : "))

for loop in range(1, 11) :
    print(loop, " x ", a, " = ", loop*a)