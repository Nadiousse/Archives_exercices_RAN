a = int(input("Veuillez entrer un nombre : "))
b = 2023
c = b - a

if c!=1 :
    print("Vous avez ", c, " ans.")
else:
    print("Vous avez ", c, " an.")