a = input("Veuillez entrer votre nom : ")
b = "Hello "

print(b+a)