HT = float(input("Veuillez saisir le prix HT : "))
Q = int(input("Veuillez sasir la quantité d'achat : "))
a = float(input("Veuillez sasir le pourcentage de TVA (sans le %) : "))
TVA = a/100
remise = 10/100

prix_sans_tva_sans_remise = HT * Q
montant_remise = prix_sans_tva_sans_remise * remise
prix_sans_tva_avec_remise = prix_sans_tva_sans_remise - montant_remise
montant_tva = prix_sans_tva_avec_remise * TVA
TTC = prix_sans_tva_avec_remise + montant_tva

print("Le total est de ", TTC, "€ TTC.")