HT = int(input("Veuillez entrer le prix HT : "))
taxe = 20/100
b = HT * taxe
TTC = HT + b

print("Le prix TTC est : ", TTC, ".")