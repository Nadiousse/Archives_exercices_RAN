a = float(input("Veuillez entrer un nombre : "))

print("L'aire du carré vaut ", a*a, ".")