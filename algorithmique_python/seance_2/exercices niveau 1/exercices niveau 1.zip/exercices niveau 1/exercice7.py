a = float(input("Entrer la largeur : "))
b = float(input("Entrer la longueur : "))
c = float(input("Entrer la hauteur : "))
volume = a*b*c

print("Le volume du parallélépipède est ", volume, ".")