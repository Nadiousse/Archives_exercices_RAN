#Pas de vérification, car il n'y a aucun moyen de prouver que le nom n'est pas valide.

a = input("Veuillez entrer votre nom : ")
b = "Hello "

print(b+a)