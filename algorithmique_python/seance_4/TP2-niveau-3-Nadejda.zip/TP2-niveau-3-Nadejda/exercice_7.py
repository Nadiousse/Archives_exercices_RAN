x = 1
y = 6
z = 5

for i in range(0,z):
    a = x * 10
    for j in range(0,y):
        print(a + j, end=" ")
    print("")
    x = x + 1