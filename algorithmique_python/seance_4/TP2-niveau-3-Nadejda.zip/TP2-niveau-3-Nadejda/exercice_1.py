import random

valeur = random.randrange(1,6)

if valeur == 1:
    print("Vous avez fait un 1.")
    print("-----")
    print("     ")
    print("  0  ")
    print("     ")
    print("-----")

if valeur == 2 :
    print("Vous avez fait un 2.")
    print("-----")
    print("0    ")
    print("     ")
    print("    0")
    print("-----")

if valeur == 3 :
    print("Vous avez fait un 3.")
    print("-----")
    print("0    ")
    print("  0  ")
    print("    0")
    print("-----")

if valeur == 4 :
    print("Vous avez fait un 4.")
    print("-----")
    print("0   0")
    print("     ")
    print("0   0")
    print("-----")

if valeur == 5 :
    print("Vous avez fait un 5.")
    print("-----")
    print("0   0")
    print("  0  ")
    print("0   0")
    print("-----")

if valeur == 6 :
    print("Vous avez fait un 6.")
    print("-----")
    print("0 0 0")
    print("     ")
    print("0 0 0")
    print("-----")