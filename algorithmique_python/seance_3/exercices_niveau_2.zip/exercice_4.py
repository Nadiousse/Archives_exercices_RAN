main_a = int(input("Nombre de doigts de A : "))
main_b = int(input("Nombre de doigts de B : "))

total = main_a + main_b

modulo = total % 2

if modulo == 0 :
    print("A a gagné.")
else:
    print("B a gagné.")