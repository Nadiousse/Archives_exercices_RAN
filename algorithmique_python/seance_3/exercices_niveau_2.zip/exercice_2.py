x = int(input("Veuillez saisir un nombre entier : "))
y = int(input("Veuillez saisir un nombre entier : "))
z = int(input("Veuillez saisir un nombre entier : "))

if x < y < z :
    print("Les nombre ont été saisis dans l'ordre croissant.")
else:
    print("Les nombre n'ont pas été saisis dans l'ordre croissant.")