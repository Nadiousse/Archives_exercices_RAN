naissance = int(input("Veuillez saisir l'année de naissance : "))
annee_actuelle = 2023
age = annee_actuelle - naissance

if age < 3 :
    print("Le bébé a gagné une palette de petits pois.")
else:
    print("Le bébé n'a rien gagné.")