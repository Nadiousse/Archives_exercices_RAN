x = int(input("Veuillez saisir un nombre allant de -1000 à 1000 : "))

if x == 0:
    print("Le nombre est nul.")
    
if x > 0:
    print("Le nombre est positif.")

if x < 0:
    print("Le nombre est négatif.")